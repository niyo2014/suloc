import{c}from"./index-abvBkYb-.js";const o=[["path",{d:"M12 6v6l4 2",key:"mmk7yg"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],r=c("clock",o);export{r as C};
