import{c as o}from"./index-abvBkYb-.js";const t=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],e=o("chevron-right",t);export{e as C};
